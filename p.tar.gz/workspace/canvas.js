var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");

ctx.fillStyle = "#ffb261";

//ctx.fillRect(0, 0, 640, 640);