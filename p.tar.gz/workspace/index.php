<html>
<head>
      
</head>

<body>
      
<center>
<canvas id="canvas" width="640" height="640"
		style="border:2px solid #000000;"></canvas>
</center>

</body>
      
<script src="canvas.js"></script>


</html>